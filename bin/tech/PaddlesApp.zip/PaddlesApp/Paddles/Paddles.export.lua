
-- paddles PRO server-side script
-- paddlesPRO.export.lua
-- version 2.5.13

package.path  = package.path..";.\\LuaSocket\\?.lua;"
package.cpath = package.cpath..";.\\LuaSocket\\?.dll;"

local socket = require("socket")

--local purge

paddles = {}


paddles.insert = {

	Start = function(self) 
		socket = require("socket")
		host = host or "localhost"
		port = port or 9090
		c = socket.try(socket.connect(host, port)) -- connect to the listener socket
		c:setoption("tcp-nodelay",true) -- set immediate transmission mode

	end,

	BeforeNextFrame = function(self)		
		
	end,
	
	AfterNextFrame = function(self)		
		local o = LoGetWorldObjects()
		for k,v in pairs(o) do
			if (v.Flags.Human == true) or (v.UnitName == "Stennis")then
				h = LoGetObjectById(k)
				--socket.try(c:send(v.UnitName .. "," .. tostring(math.deg(h.Heading)) .. "," .. tostring((h.Position.x or 0)) .. "," .. tostring((h.Position.y or 0)) .. "," .. tostring((h.Position.z or 0)) .. ""))
				socket.try(c:send(math.deg(h.Pitch) .. "," .. math.deg(h.Bank) .. "," .. math.deg(h.Heading)
				.. "," .. tostring(h.Position.x)
				.. "," .. tostring(h.Position.y)
				.. "," .. tostring(h.Position.z)
				.. "," .. tostring(h.UnitName)
				.. "," .. tostring(k)
				))
			end
			-- if v.UnitName == "Stennis" then
				-- socket.try(c:send(v.UnitName) 
				-- .. "," .. tostring((h.LatLongAlt.Lat or 0))
				-- .. "," .. tostring((h.LatLongAlt.Long or 0))
				-- .. "," .. tostring((h.LatLongAlt.Alt or 0))
				-- .. "")
			-- end
		end	
	end,

	Stop = function(self)

		
	end
}

do
	local OtherLuaExportStart=LuaExportStart
	LuaExportStart=function()
		paddles.insert:Start()	
		if OtherLuaExportStart then
			OtherLuaExportStart()
		end		
	end
end
do
	local OtherLuaExportBeforeNextFrame=LuaExportBeforeNextFrame
	LuaExportBeforeNextFrame=function()		
		paddles.insert:BeforeNextFrame()
		if OtherLuaExportBeforeNextFrame then
			OtherLuaExportBeforeNextFrame()
		end						
	end
end
do
	local OtherLuaExportAfterNextFrame=LuaExportAfterNextFrame
	LuaExportAfterNextFrame=function()		
		paddles.insert:AfterNextFrame()
		if OtherLuaExportAfterNextFrame then
			OtherLuaExportAfterNextFrame()
		end								
	end
end
do
	local OtherLuaExportStop=LuaExportStop
	LuaExportStop=function()				
		paddles.insert:Stop()					
		if OtherLuaExportStop then
			OtherLuaExportStop()
		end						
	end
end