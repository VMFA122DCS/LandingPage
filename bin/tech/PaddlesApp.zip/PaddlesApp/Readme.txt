Bear with me this will all be automated ne day.

Step 1.) Create a backup of "Export.lua" in your DCS Saved Games\Scripts directory. (Just so we dont mess up Tacview or Vaicom)

Step 2.) Within this zip file is a folder called Paddles....copy it into your DCS Saved Games\Scripts

Step 3.) Within this zip file is a script named "Export.lua" ... copy it into your DCS Saved Games\Scripts

Step 4.) Run the Paddles.exe. You will seea mostly dark screen..this is normal

Step 5.) Open DCS and run the Paddles Test Mission...Paddles will only start sending telemetry once you click "Fly"


